# BOT AQIP
BOT WHATSAPP TERMUX ONLY BY Muhammad Aqip

### Alat dan Bahan
Siapin alat dan bahannya.
```bash
> niat
> 2 handphone (1 buat jalanin sc, 1 buat scan kode qr kak)
> jaringan internet kenceng,kuota+
> penyimpanan yang memadai
> aplikasi whatsapp
> aplikasi termux
> kopi+rokok ;v
```

### Cara Installnya
Script ini di modifikasi sama saya sendiri Muhammad Aqip.
```bash
> kalo lu belum punya apk termux, download di playstore
> masuk ke apk termux lalu ketik dibawah ini!
> termux-setup-storage
> pkg install git && pkg install wget && pkg install ffmpeg && pkg install nodejs
> apt update && apt upgrade
> git clone https://github.com/MuhammadAqip/Termux-Wa-BOT
> cd Termux-Wa-BOT
> npm i -g cwebp && npm i -g ytdl && npm i  && npm i got && node index js
> Tinggal scan kode qr yeee...done
```

## Features

| AR15BOT      |                   Feature        |
| :-----------: | :------------------------------: |
|       ✅       | Sticker Creator                  |
|       ✅       | Nulis                            |
|       ✅       | Covid (new)                      |
|       ✅       | Alay (new)                       |
|       ✅       | Lirik (new)                      |
|       ✅       | Foto Anime                       |
|       ✅       | Ptl cewek/cowok (new)           |
|       ✅       | Pantun                           |
|       ✅       | Youtube Downloader               |
|       ✅       | Quotes                           |
|       ✅       | Nama (new)                       |
|       ✅       | Foto Anime                       |
|       ✅       | Pasangan (new)                   |
|       ✅       | Sholat (new )                    |
|       ✅       | Suara Google (fix)               |
|       ✅       | Quran                            |
|       ✅       | Youtube MP3 Downloader           |
|       ✅       | Intagram Downloader              |
|       ✅       | Twitter Downloader               |
|       ✅       | Facebook Downloader              |
|       ✅       | TikTok Downloader  (new)         |
|       ✅       | Wikipedia                        |
|       ✅       | Say                              |
|       ✅       | Spam Sms (new)
|       ✅       | Call (new)
|       ✅       | Spam Email (new)
|       ✅       | Seberapa Gay (new)
|       ✅       | ssweb (new)
|       ✅       | covid negara (new)
|       ✅       | ig stalk (new)
|       ✅       | Cuaca (new)
|       ✅       | Toxic (new)                      |
|       ✅       | loli.                            |
|       ✅       | hentai                           |
|       ✅       | Owner (new)                      |
|       ✅       | kata bijak                       |
|       ✅       | Fakta                            |
|       ✅       | Pokemon                          |
|       ✅       | Info                             |
|       ✅       | Donate                           |
Ket: Aktiv 24 jam

## Note
BOT INI KHUSUS HP/TERMUX DOANG YAH,JIKA MAU RE-UPLOAD CANTUMKAN NAMA SAYA (Muhammad Aqip)

## Special Thanks To
* [`A187ID`](https://github.com/A187ID)
* [`Fdciabidul`](https://github.com/fdciabdul)
* [`Bintang Nur Pradana`](https://github.com/Bintang73)

